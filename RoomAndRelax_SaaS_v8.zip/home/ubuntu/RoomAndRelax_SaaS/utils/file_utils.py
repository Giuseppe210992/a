import os
import logging
import unicodedata
import re
from datetime import datetime

logger = logging.getLogger(__name__)

def safe_cleanup(*paths):
    for path in paths:
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except Exception as e:
                logger.warning(f"Cleanup failed for {path}: {e}")

def sanitize_text(text: str) -> str:
    if not text: return ""
    normalized = unicodedata.normalize('NFKD', str(text).upper())
    cleaned = "".join([c for c in normalized if not unicodedata.combining(c)])
    cleaned = re.sub(r"[^A-Z0-9\s]", "", cleaned)
    return cleaned.strip()

def pad(text: str, length: int, left: bool = True) -> str:
    text = sanitize_text(text)[:length]
    return text.ljust(length) if left else text.rjust(length)

def ensure_168_chars(record: str) -> str:
    return record[:168].ljust(168)
