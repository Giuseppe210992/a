# Room & Relax PRO v8.0 (SaaS Edition)

Benvenuto nella versione professionale e scalabile di Room & Relax. Questo software è stato trasformato in una piattaforma multi-tenant pronta per il mercato.

## Struttura del Progetto
- `main.py`: Punto di ingresso del bot.
- `handlers.py`: Logica delle conversazioni e gestione stati.
- `services/`:
    - `database.py`: Gestione persistenza dati hotel e check-in (SQLite).
    - `ocr.py`: Analisi documenti e validazione incrociata (IA).
    - `alloggiati.py`: Integrazione SOAP con Questura.
    - `ross1000.py`: Generazione file ISTAT.
- `utils/`: Utility per file e stringhe.
- `data/`: Contiene il database `hotels.db`.

## Come Iniziare
1. Installa le dipendenze: `pip install -r requirements.txt`
2. Configura il file `.env`.
3. Avvia il bot: `python main.py`

## Per i tuoi Clienti
Ogni hotel può registrarsi autonomamente inviando i propri dati al bot. Il sistema separerà automaticamente i dati, i report e le configurazioni per ogni struttura.
