import logging
from telegram.ext import ApplicationBuilder, CommandHandler, ConversationHandler, MessageHandler, filters, CallbackQueryHandler
from config import TOKEN
from services.database import init_db
from handlers import (
    start, handle_setup, handle_start_checkin, process_doc_capo, handle_num_ospiti,
    handle_booking_photos, handle_report, CHOOSING, WAITING_SETUP, WAITING_DOC_CAPO, 
    WAITING_NUM_OSPITI, WAITING_DOC_EXTRA, WAITING_BOOKING, WAITING_PRICE, 
    CHOOSING_INVOICE, WAITING_INVOICE_DATA, WAITING_SEND_CONFIRM
)

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    
    # Inizializza il database locale
    init_db()

    app = ApplicationBuilder().token(TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            WAITING_SETUP: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_setup)],
            CHOOSING: [
                CallbackQueryHandler(handle_start_checkin, pattern="^checkin$"),
                CallbackQueryHandler(handle_report, pattern="^report$"),
                CommandHandler("start", start)
            ],
            WAITING_DOC_CAPO: [MessageHandler(filters.PHOTO | filters.Document.ALL, process_doc_capo)],
            WAITING_NUM_OSPITI: [
                CallbackQueryHandler(handle_num_ospiti),
                MessageHandler(filters.TEXT & ~filters.COMMAND, handle_num_ospiti)
            ],
            # ... (altri stati)
        },
        fallbacks=[CommandHandler("start", start)],
        allow_reentry=True
    )

    app.add_handler(conv_handler)
    print("🚀 Room and Relax SaaS Bot avviato!")
    app.run_polling()

if __name__ == "__main__":
    main()
