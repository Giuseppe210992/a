import asyncio
import logging
from datetime import datetime
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes, ConversationHandler
from services.ocr import analyze_document, cross_validate_data
from services.database import get_hotel, save_hotel, log_checkin, get_checkins_csv
from services.alloggiati import send_to_alloggiati_web, build_schedina
from services.ross1000 import generate_ross1000
from utils.file_utils import safe_cleanup
from fpdf import FPDF

# States
CHOOSING, WAITING_SETUP, WAITING_DOC_CAPO, WAITING_NUM_OSPITI, WAITING_DOC_EXTRA, \
WAITING_BOOKING, WAITING_PRICE, CHOOSING_INVOICE, WAITING_INVOICE_DATA, \
WAITING_SEND_CONFIRM = range(10)

logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    hotel = get_hotel(chat_id)
    
    if not hotel:
        await update.message.reply_text(
            "🏨 **Benvenuto in Room and Relax PRO**\n\n"
            "Non risulti ancora registrato. Per favore, configura la tua struttura.\n"
            "Invia i dati nel formato:\n"
            "`Nome Hotel | Email Admin | WSKEY Alloggiati | Codice Ross1000`",
            parse_mode="Markdown"
        )
        return WAITING_SETUP

    kb = [
        [InlineKeyboardButton("🌍 Check-in Automatico", callback_data="checkin")],
        [InlineKeyboardButton("📊 Scarica Report Mensile", callback_data="report")]
    ]
    await update.message.reply_text(
        f"🏨 **{hotel['hotel_name']}**\nGestione Check-in Attiva",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )
    return CHOOSING

async def handle_setup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        data = update.message.text.split("|")
        if len(data) < 4: raise ValueError
        save_hotel(update.effective_chat.id, data[0].strip(), data[1].strip(), data[2].strip(), data[3].strip())
        await update.message.reply_text("✅ Configurazione salvata con successo! Ora puoi usare /start")
        return ConversationHandler.END
    except:
        await update.message.reply_text("❌ Formato errato. Riprova:\n`Nome Hotel | Email | WSKEY | Codice Ross1000`", parse_mode="Markdown")
        return WAITING_SETUP

async def handle_start_checkin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("📸 Invia la foto del **Documento del Capo Famiglia**.")
    return WAITING_DOC_CAPO

async def process_doc_capo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status_msg = await update.message.reply_text("⏳ Analisi documento in corso...")
    info = await analyze_document(update.message, context)
    context.user_data["guest_info"] = info

    kb = [[InlineKeyboardButton(str(i), callback_data=f"n_{i}") for i in range(1, 6)]]
    await status_msg.edit_text(
        f"✅ **{info.get('nome', 'N/D')} {info.get('cognome', 'N/D')}**\n\n👥 Quante persone in totale?",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )
    return WAITING_NUM_OSPITI

async def handle_num_ospiti(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    num = int(query.data.split("_")[1]) if query else int(update.message.text)
    if query: await query.answer()
    
    context.user_data["people"] = num
    if num == 1:
        await (query.message if query else update.message).reply_text("📸 Invia lo screenshot della prenotazione.")
        return WAITING_BOOKING
    
    context.user_data.update({"extra_guests": [], "needed": num - 1})
    await (query.message if query else update.message).reply_text("📸 Invia il documento dell'ospite 2.")
    return WAITING_DOC_EXTRA

async def handle_booking_photos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Qui implementiamo la validazione incrociata
    status_msg = await update.message.reply_text("⏳ Validazione prenotazione in corso...")
    
    # Per semplicità usiamo l'OCR sul testo se presente, o simuliamo l'estrazione da foto
    booking_text = update.message.text if update.message.text else "Testo estratto da foto (simulato)"
    doc_data = context.user_data["guest_info"]
    
    validation = await cross_validate_data(doc_data, booking_text)
    context.user_data["validation"] = validation
    
    msg = f"💰 Importo rilevato: **{validation['suggested_amount']}**\n"
    if not validation["match"]:
        msg += "⚠️ **ATTENZIONE**: I nomi non coincidono perfettamente!\n"
        for d in validation["discrepancies"]:
            msg += f"- {d}\n"
    
    msg += "\nConferma con **OK** o scrivi l'importo corretto:"
    await status_msg.edit_text(msg, parse_mode="Markdown")
    return WAITING_PRICE

async def handle_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = update.effective_chat.id
    hotel = get_hotel(chat_id)
    csv_data = get_checkins_csv(chat_id)
    
    import io
    bio = io.BytesIO(csv_data.encode())
    bio.name = f"report_{hotel['hotel_name']}.csv"
    
    await query.message.reply_document(bio, caption=f"📊 Report Check-in per {hotel['hotel_name']}")
    await query.answer()

# ... (resto degli handler simili alla v7.4 ma con log_checkin alla fine)
async def finalize_checkin(message, context: ContextTypes.DEFAULT_TYPE):
    data = context.user_data
    chat_id = message.chat_id
    hotel = get_hotel(chat_id)
    guests = [data.get("guest_info", {})] + data.get("extra_guests", [])
    
    # Log nel database
    log_checkin(chat_id, guests[0].get('nome'), guests[0].get('cognome'), data.get('amount', 'N/D'))
    
    # Generazione file (Alloggiati, Ross1000, PDF) usando i dati dell'hotel dal DB
    # ... (codice generazione file)
    
    await message.reply_text(f"✅ Check-in completato per {hotel['hotel_name']}. Dati pronti per l'invio.")
    return WAITING_SEND_CONFIRM
