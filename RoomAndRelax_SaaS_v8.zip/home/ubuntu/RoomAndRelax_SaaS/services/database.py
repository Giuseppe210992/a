import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "data" / "hotels.db"

def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS hotels (
            chat_id INTEGER PRIMARY KEY,
            hotel_name TEXT,
            admin_email TEXT,
            wskey TEXT,
            ross1000_code TEXT,
            config_json TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS checkins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER,
            guest_name TEXT,
            guest_surname TEXT,
            checkin_date TEXT,
            amount TEXT,
            status TEXT,
            FOREIGN KEY (chat_id) REFERENCES hotels (chat_id)
        )
    ''')
    conn.commit()
    conn.close()

def get_hotel(chat_id):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM hotels WHERE chat_id = ?', (chat_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def save_hotel(chat_id, hotel_name, admin_email, wskey, ross1000_code):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO hotels (chat_id, hotel_name, admin_email, wskey, ross1000_code)
        VALUES (?, ?, ?, ?, ?)
    ''', (chat_id, hotel_name, admin_email, wskey, ross1000_code))
    conn.commit()
    conn.close()

def log_checkin(chat_id, name, surname, amount, status="COMPLETED"):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO checkins (chat_id, guest_name, guest_surname, checkin_date, amount, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (chat_id, name, surname, date_str, amount, status))
    conn.commit()
    conn.close()

def get_checkins_csv(chat_id):
    import csv
    import io
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT guest_name, guest_surname, checkin_date, amount, status FROM checkins WHERE chat_id = ?', (chat_id,))
    rows = cursor.fetchall()
    conn.close()
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Nome', 'Cognome', 'Data Check-in', 'Importo', 'Stato'])
    writer.writerows(rows)
    return output.getvalue()
