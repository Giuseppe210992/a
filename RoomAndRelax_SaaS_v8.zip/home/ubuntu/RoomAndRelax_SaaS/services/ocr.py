import tempfile
import logging
import cv2
import easyocr
import json
from openai import OpenAI
from config import OPENAI_API_KEY
from utils.file_utils import safe_cleanup

client = OpenAI(api_key=OPENAI_API_KEY)
logger = logging.getLogger(__name__)

_reader = None

def get_reader():
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(['it', 'en', 'fr', 'es', 'de'], gpu=False)
    return _reader

def preprocess_image(image_path):
    img = cv2.imread(image_path)
    if img is None: return image_path
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if gray.shape[1] < 1000:
        gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    denoised = cv2.fastNlMeansDenoising(gray, h=10)
    thresh = cv2.adaptiveThreshold(denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    processed_path = image_path.replace(".jpg", "_processed.jpg")
    cv2.imwrite(processed_path, thresh)
    return processed_path

async def analyze_document(message, context):
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
        temp_path = tmp.name
    
    photo = message.photo[-1] if message.photo else message.document
    file = await context.bot.get_file(photo.file_id)
    await file.download_to_drive(temp_path)
    
    processed = preprocess_image(temp_path)
    reader = get_reader()
    text = " ".join(reader.readtext(processed or temp_path, detail=0))[:2500]
    safe_cleanup(temp_path, processed if processed != temp_path else None)

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": "Estrai in JSON: nome, cognome, data_nascita (gg/mm/aaaa), num_doc, sesso (M/F), cittadinanza."},
                  {"role": "user", "content": text}],
        response_format={"type": "json_object"}
    )
    return json.loads(res.choices[0].message.content.strip())

async def cross_validate_data(doc_data, booking_text):
    """
    Usa l'LLM per confrontare i dati del documento con il testo della prenotazione.
    """
    prompt = f"""
    Confronta i dati del documento con il testo della prenotazione.
    Dati Documento: {json.dumps(doc_data)}
    Testo Prenotazione: {booking_text}
    
    Ritorna un JSON con:
    - match (boolean): true se i nomi coincidono sostanzialmente
    - discrepancies (list): lista di stringhe con le differenze trovate (es. "Nome diverso", "Data arrivo non coincide")
    - suggested_amount (string): importo trovato nella prenotazione
    """
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": "Sei un assistente esperto in check-in alberghieri. Valida i dati."},
                  {"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    return json.loads(res.choices[0].message.content.strip())
